/** BaseUrl & Core url  */
define('WP_HOME', 'http://0.0.0.0:9999');
define('WP_SITEURL', 'http://0.0.0.0:9999');

/** MySQL database name */
define('DB_NAME', 'wp');

/** MySQL database username */
define('DB_USER', 'wp');

/** MySQL database password */
define('DB_PASSWORD', 'wp');

/** MySQL hostname */
define('DB_HOST', 'mysql');

/** Debug mode */
define('WP_DEBUG', true);

/** Caching */
define( 'WP_CACHE', false );
